package com.hanwha.hive_web.config.nexacro.data.convert;

import com.nexacro17.xapi.data.Variable;

public class ConvertVariableEvent extends ConvertEvent {

    /* serialVersionUID */
    private static final long serialVersionUID = 7527494468054562758L;
    
    /**
     * Statements
     *
     * @param source
     */
    public ConvertVariableEvent(Variable source, Object targetValue) {
        super(source, targetValue);
    }

}
