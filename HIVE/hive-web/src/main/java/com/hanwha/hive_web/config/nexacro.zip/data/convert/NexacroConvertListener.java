package com.hanwha.hive_web.config.nexacro.data.convert;

import java.util.EventListener;

public interface NexacroConvertListener extends EventListener {
    
	/**
	 * 대상 객체에 값이 할당되기 직전 호출 된다.
	 * <code>DataSet</code>의 각행의 값 변환 혹은 <code>Variable</code>의 값 변환
	 * @param event
	 */
    void convertedValue(ConvertEvent event);

}
