package com.hanwha.hive_web.config.nexacro.util;

public class ReflectionFailException extends RuntimeException {
    
    public ReflectionFailException(String message) {
        super(message);
    }

    public ReflectionFailException(String message, Throwable cause) {
        super(message, cause);
    }

}
