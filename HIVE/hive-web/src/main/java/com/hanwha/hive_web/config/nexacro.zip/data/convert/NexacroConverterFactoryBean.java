package com.hanwha.hive_web.config.nexacro.data.convert;

import java.util.Set;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;

public class NexacroConverterFactoryBean implements FactoryBean<NexacroConverterFactory>, InitializingBean {

    private Set<NexacroConverter> converters;
    
    private NexacroConverterFactory converterFactory;
    
    /**
     * @param converters the converters to set
     */
    public void setConverters(Set<NexacroConverter> converters) {
        this.converters = converters;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.converterFactory = NexacroConverterFactory.getInstance();
        converterFactory.register(converters);
    }

    @Override
    public NexacroConverterFactory getObject() throws Exception {
        return converterFactory;
    }

    @Override
    public Class<NexacroConverterFactory> getObjectType() {
        return NexacroConverterFactory.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

}
