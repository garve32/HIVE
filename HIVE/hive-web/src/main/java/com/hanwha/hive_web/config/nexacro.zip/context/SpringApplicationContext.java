package com.hanwha.hive_web.config.nexacro.context;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class SpringApplicationContext implements ApplicationContextAware {
    private static ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    /**
     * Spring Application Context에 대한 엑세스를 제공한다.
     * 해당 메소드를 이용하여 특정 객체를 호출할 경우에는 적절한 대상 클래스로 캐스팅해야 한다.
     * 만약 bena이 존재하지 않을경우에는 Runtime 에러가 throw 된다.
     * @param beanName bean 이름(아이디)
     * @return bean 이름에 해당하는 객체 참조
     */
    public static Object getBean(String beanName) {
        return context.getBean(beanName);
    }

    /**
     * requiredType type의 bean을 반환한다.
     * @param requiredType type the bean must match; can be an interface or superclass.
     * @return an instance of the single bean matching the required type
     */
    public static <T> T getBean(Class<T> requiredType) {
        return context.getBean(requiredType);
    }
}