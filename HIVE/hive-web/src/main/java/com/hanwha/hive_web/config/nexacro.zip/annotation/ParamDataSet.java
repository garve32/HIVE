package com.hanwha.hive_web.config.nexacro.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <p><code>DataSet</code>을 List혹은 POJO형태의 데이터로 변환을 수행하기 위한 annotation이다.
 * 
 * @author owner01
 *
 */
@Target({ java.lang.annotation.ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ParamDataSet {
	/**
	 * <code>DataSet</code>의 식별자
	 * @return dsName
	 */
	String name();
	
	/**
	 * Whether the parameter is required.
	 * <p>Default is {@code true}, leading to an exception thrown in case
	 * of the parameter missing in the request. Switch this to {@code false}
	 * if you prefer a {@code null} in case of the parameter missing.
	 */
	boolean required() default true;
}
