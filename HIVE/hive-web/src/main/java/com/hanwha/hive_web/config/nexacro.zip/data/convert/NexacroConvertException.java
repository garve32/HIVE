package com.hanwha.hive_web.config.nexacro.data.convert;

import com.hanwha.hive_web.config.nexacro.NexacroException;

public class NexacroConvertException extends NexacroException {

    /* serialVersionUID */
    private static final long serialVersionUID = 2572392591528637297L;

    /**
     * 기본 생성자이다.
     */
    public NexacroConvertException() {
        ;
    }

    /**
     * 메시지를 가지는 생성자이다.
     * 
     * @param message
     *            메시지
     */
    public NexacroConvertException(String message) {
        super(message);
    }

    /**
     * 메시지와 원천(cause) 예외를 가지는 생성자이다.
     * 
     * @param message
     *            메시지
     * @param cause
     *            원천 예외
     */
    public NexacroConvertException(String message, Throwable cause) {
        super(message, cause);
    }


}
