package com.hanwha.hive_web.config.nexacro.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.hanwha.hive_web.config.nexacro.context.NexacroContext;
import com.hanwha.hive_web.config.nexacro.context.NexacroContextHolder;
import com.nexacro17.xapi.data.Debugger;
import com.nexacro17.xapi.data.PlatformData;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class NexacroInterceptor extends HandlerInterceptorAdapter {

    /**
     * This implementation always returns <code>true</code>.
     */
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        parseNexacroRequest(request, response, handler);
        return true;
    }

    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        super.afterCompletion(request, response, handler, ex);
    }

    private void parseNexacroRequest(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        StopWatch sw = new StopWatch(getClass().getSimpleName());
        try {
            sw.start("parse request");
            NexacroContext context = NexacroContextHolder.getNexacroContext(request, response);
            PlatformData platformData = context.getPlatformData();
            if(log.isDebugEnabled()) {
            	log.debug("got request=[{}]", new Debugger().detail(platformData));
            }
        } finally {
            sw.stop();
            if(log.isTraceEnabled()) {
            	log.trace(sw.prettyPrint());
            }
        }
      
    }
    
}
